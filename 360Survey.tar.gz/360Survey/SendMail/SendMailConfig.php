<?php

return array(
  'smtp_server' => 'mail.3rdwavepower.com',
  'primary_port' => 25,
  'secondary_port' => 587,
  'user_email' => 'survey360@3rdwavepower.com',
  'user_name' => 'Survey360 Admin',
  'password' => 'Dell@0786',
  'debug_level' => 3,
  'time_out' => 30,
  'time_zone' => 'Asia/Colombo'
);