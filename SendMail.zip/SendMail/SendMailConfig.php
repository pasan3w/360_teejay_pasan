<?php

return array(
  'smtp_server' => 'mail.3rdwavepower.com',
  'primary_port' => 587,
  'secondary_port' => 25,
  'user_email' => 'survey360@3rdwavepower.com',
  'user_name' => 'Multipoint Admin - 3WConsulting',
  'password' => 'Dell@0786',
  'debug_level' => 3,
  'time_out' => 100,
  'time_zone' => 'Asia/Colombo'
);